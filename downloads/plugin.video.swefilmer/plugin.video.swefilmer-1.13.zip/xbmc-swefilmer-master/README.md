xbmc-swefilmer
==============

With this addon you can stream content from Swefilmer (www.swefilmer.com).
